# Nixe Smoke Cogs (Leina-style)

Run:
  python scripts/smoke_cogs.py
Options:
  --only SUBSTR     # contoh: --only lucky_pull
  --exclude a.py,b.py

Output format mengikuti Leina's smoke (OK/FAIL per modul).
