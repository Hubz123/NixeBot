from __future__ import annotations
import discord
async def handle_on_message(bot, message: discord.Message):
    return
