# smoke-safe init
