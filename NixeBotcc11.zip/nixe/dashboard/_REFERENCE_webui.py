"""
Reference UI merged endpoints (disabled in this build).
"""
