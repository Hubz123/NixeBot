print('ok')
